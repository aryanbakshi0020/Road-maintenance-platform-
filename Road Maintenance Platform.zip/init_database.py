# init_database.py - Schema setup only, NO admin user creation
import psycopg2
import sys
import os
from getpass import getpass

def init_database():
    print("🚀 Initializing Road Maintenance Platform Database...")
    
    # Get database connection parameters from environment
    db_host = os.environ.get('DB_HOST', 'localhost')
    db_port = os.environ.get('DB_PORT', '5432')
    db_name = os.environ.get('DB_NAME', 'road_maintenance')
    db_user = os.environ.get('DB_USER', 'postgres')
    db_password = os.environ.get('DB_PASSWORD')
    
    if not db_password:
        db_password = getpass("Enter PostgreSQL password: ")
    
    try:
        conn = psycopg2.connect(
            host=db_host,
            user=db_user,
            password=db_password,
            database=db_name,
            port=db_port
        )
        conn.autocommit = True
        cursor = conn.cursor()
        
        print("✅ Connected to PostgreSQL")
        
        # SQL commands for schema only - NO USER CREATION
        sql_commands = [
            # Install PostGIS
            "CREATE EXTENSION IF NOT EXISTS postgis;",
            
            # Users table
            """CREATE TABLE IF NOT EXISTS users (
                id SERIAL PRIMARY KEY,
                username VARCHAR(64) UNIQUE NOT NULL,
                email VARCHAR(120) UNIQUE NOT NULL,
                password_hash VARCHAR(256),
                is_admin BOOLEAN DEFAULT false NOT NULL,
                created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
                last_login TIMESTAMP WITH TIME ZONE
            );""",
            
            # Issues table
            """CREATE TABLE IF NOT EXISTS issues (
                id SERIAL PRIMARY KEY,
                title VARCHAR(200) NOT NULL,
                description TEXT NOT NULL,
                category VARCHAR(50) NOT NULL,
                latitude FLOAT NOT NULL,
                longitude FLOAT NOT NULL,
                location GEOMETRY(POINT, 4326) NOT NULL,
                status VARCHAR(20) DEFAULT 'reported' NOT NULL,
                created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
                user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
                resolved_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
                resolved_at TIMESTAMP WITH TIME ZONE
            );""",
            
            # Indexes
            "CREATE INDEX IF NOT EXISTS idx_issues_location ON issues USING GIST(location);",
            "CREATE INDEX IF NOT EXISTS idx_issues_category ON issues(category);",
            "CREATE INDEX IF NOT EXISTS idx_issues_status ON issues(status);",
            
            # Trigger function
            """CREATE OR REPLACE FUNCTION update_issue_location()
            RETURNS TRIGGER AS $$
            BEGIN
                NEW.location := ST_SetSRID(ST_MakePoint(NEW.longitude, NEW.latitude), 4326);
                NEW.updated_at := CURRENT_TIMESTAMP;
                RETURN NEW;
            END;
            $$ LANGUAGE plpgsql;""",
            
            "DROP TRIGGER IF EXISTS trg_issue_location ON issues;",
            """CREATE TRIGGER trg_issue_location
            BEFORE INSERT OR UPDATE ON issues
            FOR EACH ROW EXECUTE FUNCTION update_issue_location();"""
        ]
        
        print("📋 Setting up database schema...")
        
        for i, command in enumerate(sql_commands, 1):
            try:
                cursor.execute(command)
                print(f"  ✅ Step {i}: Executed")
            except Exception as e:
                if "already exists" in str(e) or "duplicate" in str(e).lower():
                    print(f"  ✓ Step {i}: Already exists")
                else:
                    print(f"  ⚠ Step {i}: {str(e)[:80]}")
        
        print("\n✅ Database schema created successfully!")
        print("\n" + "="*50)
        print("⚠️ IMPORTANT: Admin user NOT created by this script")
        print("   Create admin user directly in PostgreSQL:")
        print("   1. Generate password hash (see documentation)")
        print("   2. Run: INSERT INTO users (...) VALUES (...)")
        print("="*50)
        
        cursor.close()
        conn.close()
        return True
        
    except Exception as e:
        print(f"❌ Database initialization failed: {e}")
        return False

if __name__ == "__main__":
    print("=" * 50)
    print("Road Maintenance Platform - Database Schema Setup")
    print("=" * 50)
    
    if init_database():
        print("\n✅ Schema setup complete")
    else:
        print("\n❌ Schema setup failed")
        sys.exit(1)