# generate_hash.py - Run this once, then DELETE IT
from werkzeug.security import generate_password_hash

# ENTER YOUR DESIRED PASSWORD HERE
your_password = input("Enter your admin password: ")
hash_value = generate_password_hash(your_password)
print(f"\nCopy this hash:\n{hash_value}")

